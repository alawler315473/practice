﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopGame
{
    public class Character:Entity
    {
        public int health;
        public int strength;
        public int defense;
        public string name;

        public Character(int Health, int Strength, int Defence)
        {
            health = Health;
            strength = Strength;
            defense = Defence;
        }
        public void takeDamage(Enemy enemy)
        {
            health = (health - (enemy.strength - enemy.defense));
        }
    }
}
