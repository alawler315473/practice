﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritancePrac
{
    class MOBA : Game
    {
        public MOBA(int difficulty, int gameComplexity)
        {
            difficulty = 2;
            gameComplexity = 4;
        }
        public void PlaySolo(Player player, Game game)
        {
            player.skillLevel++;
            player.wellRestedPts = (player.wellRestedPts - 3);
        }
        public void PlayArranged(Player player)
        {
            player.skillLevel = (player.skillLevel + 2);
            player.wellRestedPts = (player.wellRestedPts + 5);
        }
    }
}
