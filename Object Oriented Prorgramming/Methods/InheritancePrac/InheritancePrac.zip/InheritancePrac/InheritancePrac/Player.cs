﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritancePrac
{
    class Player
    {
        public int skillLevel;
        public int wellRestedPts;

        public Player(int skillLevel, int wellRested)
        {
            skillLevel = 0;
            wellRested = 100;
        }
    }
}
