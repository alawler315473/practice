﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritancePrac
{
    class Game
    {
        public int difficluty;
        public int gameComplexity;

        public void GitGud(Player player, RTS rts)
        {
            player.skillLevel = (player.skillLevel - rts.gameComplexity);
            player.wellRestedPts = (player.wellRestedPts - rts.gameComplexity);
        }

        public void GoToSleep(Player player)
        {
            player.wellRestedPts = (player.wellRestedPts + 10);
        }
    }
}
